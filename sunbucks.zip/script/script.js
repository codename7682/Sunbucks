$(document).ready(function(){
    
    //    #ham을 눌렀을때
    //    #mnav의 height를 auto로 지정한다.
    
    var stat = 0;
    // stat이 0이라는 뜻은 메뉴가 안보이고있다
    // stat이 1이라는 뜻은 메뉴가 보이고있다
    
    $("#ham").click(function(){
        if(stat == 0){
            $("#mnav").css("height","auto");
            $(this).addClass("ex");
            stat = 1;
            $("html,body").css("overflow","hidden");
            $("#mnav").css("overflow","auto");
        }else{
            $("#mnav").css("height","0px");
            $(this).removeClass("ex");
            stat = 0;
            $("html,body").css("overflow","auto");
            $("#mnav").css("overflow","auto");
        }
    });
    
    $(".mmain>a").click(function(e){
        e.preventDefault();
    });
    
    // .mmain을 클릭했을때
    // "그" 안에 들어있는 .msub를 나타나게(사라지게) 하자.
    $(".mmain").click(function(){
        $(this).siblings().find(".tri").removeClass("rev");
        $(this).find(".tri").toggleClass("rev");
        $(this).siblings().children(".msub").slideUp();
        $(this).children(".msub").slideToggle();
    });
    
    
//    var timing = Math.floor(Math.random()*(5000-3000))+3000;
//    setTimeout(function(){
//        $("#bs").show();
//    },timing);
    
    // 카드들의 높이를 잰다.
    // 그 값들중에서 가장 큰 값이 얼마인가를 알아냄
    // 모든 카드들에게 그 값을 높이로 적용.
    

    function cardsizer(){
        $(".card").height("auto");
        var carh = new Array();
        var len = $(".card").length;
        for(i=0; i<len; i++){
            carh[i] = $(".card").eq(i).outerHeight();
        }
        var mx = Math.max.apply(null, carh);
        $(".card").height(mx);
    }
    
    setTimeout(cardsizer,500);
    
    $(window).resize(function(){
        cardsizer();
    });
    
});












$(document).ready(function(){
    
    var cur = 0;
    var len = $(".slide").length;
    
    function sliding(dir){
        cur = cur + dir;
        if(cur >= len){
            cur = 0;
        }else if(cur < 0){
            cur = len - 1;
        }
        $(".slide").fadeOut();
        $(".slide").eq(cur).stop().fadeIn();
    }
    
    var auto = setInterval(sliding, 3000, 1);
        
    $(".btn").mouseover(function(){
        clearInterval(auto);
    });
    $(".btn").mouseout(function(){
        auto = setInterval(sliding, 3000, 1);        
    });
    
    
    $(".right").click(function(){
        sliding(1);
    });
    
    $(".left").click(function(){
        sliding(-1);
    });
    
    var imgratio = $("#slider img").width() / $("#slider img").height();
    // #slider안에 있는 img의 가로 세로길이를 측정.
    // imgratio라는 변수에 그림의 가로/세로를 대입.
    
    function sizer(){
        var boxratio = $("#slider").width() / $("#slider").height(); 
            // #slider의 가로길이와 세로길이를 측정.
            // boxratio라는 변수에 박스의 가로/세로를 대입.
            // 결론, 두 사각형의 비율을 계산하여 비교했을때
            // 그 비율이 더 큰 사각형이 가로로 더 길쭉하다는 뜻.
        if(boxratio >= imgratio){
            // boxratio가 imgratio보다 크다는 뜻은
            // 이미지보다 박스가 좌우로 더 길다는 뜻이므로
            // 이때는 img의 가로길이를 100%, 세로길이를 auto로 지정.
            $("#slider img").width("100%").height("auto");
        }else{
            // boxratio가 imgratio보다 작다는 뜻은
            // 이미지보다 박스가 세로로 더 길다는 뜻이므로
            // 이때는 img의 세로길이를 500px, 가로길이를 auto로 지정.
            $("#slider img").height(500).width("auto");
        }
    }
    
    
    sizer();
    $(window).resize(function(){
        sizer();
    });
    
    
});












